import matplotlib.pyplot as plt

# Points
A = (1, 2)
B = (2, 3)
P = (8, 9)  # Found y = 9

# Plotting points
plt.figure(figsize=(6,6))
plt.plot([A[0], B[0]], [A[1], B[1]], 'bo-', label="Line AB")
plt.plot(P[0], P[1], 'ro', label="Point P(8,9)")

# Annotating
plt.text(A[0]+0.1, A[1], 'A(1,2)')
plt.text(B[0]+0.1, B[1], 'B(2,3)')
plt.text(P[0]+0.1, P[1], 'P(8,9)')

# Axis and grid
plt.axhline(0, color='black', linewidth=0.5)
plt.axvline(0, color='black', linewidth=0.5)
plt.grid(True)
plt.legend()
plt.title("Point P dividing AB in ratio -7:6")

# Save before show
plt.savefig("/Figs/fig_1.png")  # saves in current folder
plt.show()
